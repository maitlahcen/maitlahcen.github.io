% *****************************************************************************
%  Universite de Lausanne - HEC - MScE - Master thesis - Spring 2014
%  ----------------------------------------------------------------------------
%  DSGE models for developing countries: an application to the Moroccan economy
%  Mohammed Ait Lahcen
% *****************************************************************************

clc; clear all; close all;

setenv('LD_LIBRARY_PATH', '');
addpath('/usr/share/dynare/matlab');
addpath('/home/maitlahcen/Dropbox/Master thesis/DSGE Morocco/Data');


% ----------------------------------------------------------
% Importing data
% ----------------------------------------------------------

% -------- Sample specification -----------------
dates       = [1998.00 : 0.25 : 2013.50];
startdate   = 1998.00; 
enddate     = 2013.50;

startindex  = find(dates == startdate); % position of starting year of sample
endindex    = find(dates == enddate); % position of ending year of sample
xxaxis  = [startdate : 0.25 : enddate]';

% -------- Load the data -------------------------
[data]  = xlsread('NK_SOE_Data.xlsx',1,'B2:U64');
T       = size(data,1);
N       = size(data,2);

nY      = data(:,1);    % Nominal GDP
Y       = data(:,2);    % Real GDP
nY_t    = data(:,3);    % Nominal tradables output
Y_t     = data(:,4);    % Real tradables output
nY_n    = data(:,5);    % Nominal non-tradables output
Y_n     = data(:,6);    % Real non-tradables output
C       = data(:,7);    % Real consumption
I       = data(:,8);    % Real investment
G       = data(:,9);    % Real government expenditures
X       = data(:,10);   % Exports in volume
nX      = data(:,11);   % Exports in value
M       = data(:,12);   % Imports in volume
nM      = data(:,13);   % Imports in value
CPI     = data(:,14);   % CPI inflation
R       = data(:,15);   % Interbank interest rate
Q       = data(:,16);   % Effective exchange rate
E       = data(:,17);   % Nominal exchange rate
Y_star  = data(:,18);   % Euro area real GDP
CPI_star  = data(:,19); % Euro area CPI inflation
R_star  = data(:,20);   % Euro area short-term interest rates

plot(dates,Y,'g');
hold all;
plot(dates,CPI,'r');
hold off;

% -------- Computing average annual growth ------------------

[growth_data] = [Y Y_t Y_n C I G X M];
growth = zeros(T,size(growth_data,2));

for j = 1 : size(growth_data,2)
    for jjj = 5 : T
        growth(jjj,j) = log(growth_data(jjj,j)) - log(growth_data(jjj-4,j));
    end
end

mean(growth)*100;
std(growth);
plot(dates,growth(:,1:4));

% -------- Computing long-term shares ------------------

C_over_Y = C./Y;        % Share of consumption in GDP
mean(C_over_Y);
plot(dates,C_over_Y);

G_over_Y = G./Y;        % Share of government spending in GDP
mean(G_over_Y);
plot(dates,G_over_Y);

X_over_Y = X./Y;        % Share of exports in GDP
mean(X_over_Y);
M_over_Y = M./Y;        % Share of imports in GDP
mean(M_over_Y);

Yt_over_Y = Y_t./Y;        % Share of tradables in GDP
mean(Yt_over_Y);
Yn_over_Y = Y_n./Y;        % Share of non-tradables in GDP
mean(Yn_over_Y);

X_over_Yt = X./Y_t;        % Share of exports in tradables GDP
mean(X_over_Yt);
M_over_Yt = M./Y_t;        % Share of exports in tradables GDP
mean(M_over_Yt);

plot(dates,X_over_Y,'g');
hold all;
plot(dates,M_over_Y,'r');
hold off;

% -------- Computing GDP Deflator based inflation ------------------

Deflat = nY./Y; % GDP deflator
INFL = zeros(T,1); % Inflation based on GDP defaltor

for jjj = 5 : T
    INFL(jjj,1) = log(Deflat(jjj,1)) - log(Deflat(jjj-4,1));
end
INFL   = INFL(startindex:endindex,:);

Deflat_t = nY_t./Y_t; % Tradables GDP deflator
INFL_t = zeros(T,1); % Tradables inflation based on Tradable GDP deflator

for jjj = 5 : T
    INFL_t(jjj,1) = log(Deflat_t(jjj,1)) - log(Deflat_t(jjj-4,1));
end
INFL_t   = INFL_t(startindex:endindex,:);

Deflat_n = nY_n./Y_n; % Non-tradables GDP deflator
INFL_n = zeros(T,1); % Non-tradables inflation based on non-tradables GDP defaltor

for jjj = 5 : T
    INFL_n(jjj,1) = log(Deflat_n(jjj,1)) - log(Deflat_n(jjj-4,1));
end
INFL_n   = INFL_n(startindex:endindex,:);

plot(dates,INFL*100,'g');
hold all;
plot(dates,INFL_n*100,'r');
hold all;
plot(dates,INFL_t*100,'b');
hold off;


% -------- Computing terms of trade ------------------
% terms of trade = the ratio between exports and imports deflators

X_deflat = nX./X; % Exports deflator
M_deflat = nM./M; % Imports deflator

S = X_deflat./M_deflat;
plot(dates,S); % Terms of trade are deteriorating

% -------- Computing Imports inflation ------------------

for jjj = 5 : T
    INFL_M(jjj,1) = log(M_deflat(jjj,1)) - log(M_deflat(jjj-4,1)); % Imports inflation based on imports defaltor
end
INFL_M   = INFL_M(startindex:endindex,:);


% -------- Transforming the data ------------------

y = log(Y);
y_t = log(Y_t);
y_n = log(Y_n);
c = log(C);
i = log(I);
g = log(G);
x = log(X);
m = log(M);
pi = log((1+(CPI/100)).^(1/4)); % Transfroming annual inflation into quarterly inflation
pi_m = log((1+INFL_M).^(1/4));
r = log((1+(R/100)).^(1/4)); % Transfroming annual interest rates into quarterly interest rates
q = log(Q);
e = log(E);
s = log(S);
y_star = log(Y_star);
pi_star = log((1+(CPI_star/100)).^(1/4));
r_star = log((1+(R_star/100)).^(1/4));

% plot(dates,pi,'r');
% hold all;
% plot(dates,pi2,'b');
% hold off;

%-----------------------------
% HP filtering variables
%-----------------------------

[y_bar,y_hat] = hpfilter(y,1600);
[y_t_bar,y_t_hat] = hpfilter(y_t,1600);
[y_n_bar,y_n_hat] = hpfilter(y_n,1600);
[c_bar,c_hat] = hpfilter(c,1600);
[i_bar,i_hat] = hpfilter(i,1600);
[g_bar,g_hat] = hpfilter(g,1600);
[x_bar,x_hat] = hpfilter(x,1600);
[m_bar,m_hat] = hpfilter(m,1600);
[pi_bar,pi_hat] = hpfilter(pi,1600);
[pi_m_bar,pi_m_hat] = hpfilter(pi_m,1600);
[r_bar,r_hat] = hpfilter(r,1600);
[q_bar,q_hat] = hpfilter(q,1600);
[e_bar,e_hat] = hpfilter(e,1600);
[s_bar,s_hat] = hpfilter(s,1600);
[y_star_bar,y_star_hat] = hpfilter(y_star,1600);
[pi_star_bar,pi_star_hat] = hpfilter(pi_star,1600);
[r_star_bar,r_star_hat] = hpfilter(r_star,1600);

% plot(dates,pi_hat,'r');
% hold all;
% plot(dates,y_hat,'b');
% hold off;
% 
% plot(dates,pi_m_hat-pi_star_hat,'r');
% hold all;
% plot(dates,[0; diff(e_hat)],'b');
% hold off;


%-----------------------------
% Business cycle figures
%-----------------------------

vlist   = {'y','y_t','y_n','c'};
vnames  = {'Total Output','Tradables Output','Non-tradables Output','Consumption'};

figure(1)
for j = 1 : length(vnames)
    subplot(2,2,j)
    [AX,H1,H2] = plotyy(dates,eval(vlist{j}),dates,eval(strcat(vlist{j},'_hat')));
    H3 = line(dates,eval(strcat(vlist{j},'_bar')),'Parent',AX(1));
    H4 = line(dates,0,'Parent',AX(2));
    set(AX,'xlim',[startdate enddate],'xtick',[startdate:2:enddate]);
    set(AX(1),'ylim',[min(eval(vlist{j}))-0.1 max(eval(vlist{j}))+0.1]);
    set(AX(2),'ylim',[-0.3,0.3]);
    set(AX(1),'YTick',[1:0.25:15]);
    set(AX(2),'YTick',[-0.3:0.1:0.3])
    set(H1,'Color','b');
    set(H2,'LineStyle','-','Color','r');
    set(H3,'Color','g');
    title(vnames{j});
    axis manual
    %legend('Log','HP filtered trend','HP filtered cycle');
    hold all
end

vlist   = {'i','g','x','m'};
vnames  = {'Investment','Government spending','Exports','Imports'};

figure(2)
for j = 1 : length(vnames)
    subplot(2,2,j)
    [AX,H1,H2] = plotyy(dates,eval(vlist{j}),dates,eval(strcat(vlist{j},'_hat')));
    H3 = line(dates,eval(strcat(vlist{j},'_bar')),'Parent',AX(1));
    H4 = line(dates,0,'Parent',AX(2));
    set(AX,'xlim',[startdate enddate],'xtick',[startdate:2:enddate]);
    set(AX(1),'ylim',[min(eval(vlist{j}))-0.1 max(eval(vlist{j}))+0.1]);
    set(AX(2),'ylim',[-0.3,0.3]);
    set(AX(1),'YTick',[1:0.25:15]);
    set(AX(2),'YTick',[-0.3:0.1:0.3])
    set(H1,'Color','b');
    set(H2,'LineStyle','-','Color','r');
    set(H3,'Color','g');
    title(vnames{j});
    axis manual
    %legend('Log','HP filtered trend','HP filtered cycle');
    hold all
end

vlist   = {'pi','pi_m','r','e','q','s'};
vnames  = {'CPI inflation','Imports inflation','Nominal interest rate','Nominal exchange rate','Real exchange rate','Terms of trade'};

figure(3)
for j = 1 : length(vnames)
    subplot(3,2,j)
    AX = plot(dates,eval(vlist{j}),'b',dates,eval(strcat(vlist{j},'_bar')),'-r');
    set(gca,'xlim',[startdate enddate],'xtick',[startdate:2:enddate]);
    %set(gca,'ylim',[min(eval(vlist{j})) max(eval(vlist{j}))]);
    %set(gca,'YTick',[-5:0.1:5])
    title(vnames{j});
    %axis manual
    %legend('Log','HP filtered trend','FontSize',4);
    hold all
end
hold off


%-----------------------------
% Business cycle statistics
%-----------------------------

[data_stat] = [y_hat y_t_hat y_n_hat c_hat i_hat g_hat x_hat m_hat pi_hat r_hat q_hat e_hat s_hat];

V               = size(data_stat,2);
[data_acf]      = zeros(5,V);
[data_adf]      = zeros(1,V);
[data_std]      = zeros(1,V);
[data_relstd]   = zeros(1,V);
[data_corr]     = zeros(1,V);

for t = 1:V
data_acf(:,t)   = autocorr(data_stat(:,t),4);
data_adf(1,t)   = adftest(data_stat(:,t),'model','ARD');  % ADF test for stationarity
data_std(1,t)   = std(data_stat(:,t));
data_relstd(1,t)= std(data_stat(:,t))/std(data_stat(:,1));
data_corr(1,t)  = corr(data_stat(:,1),data_stat(:,t));
end

data_std    = round(data_std*10000)/100 ;
data_relstd = round(data_relstd*100)/100 ;
data_acf    = round(data_acf*100)/100 ;
data_corr   = round(data_corr*100)/100 ;

disp('Y Y_t Y_n C I G X M R Q E Pi S')
disp(data_acf)

%-----------------------------------
% Euro area AR(1) processes
%-----------------------------------

% model = arima('ARLags',1,'Constant',0);
% y_star_ar1 = estimate(model,y_star_hat)
% pi_star_ar1 = estimate(model,pi_star_hat)
% r_star_ar1 = estimate(model,r_star_hat)

%-----------------------------------
% Nominal exchange rate AR(1) processes
%-----------------------------------

% e_ar1 = estimate(model,e_hat)


%-----------------------------------
% Storing observables for estimation
%-----------------------------------

[data_est] = [y_t_hat y_n_hat pi_hat r_hat q_hat];
save('data_est.mat', 'data_est')


%-----------------------------------
% Starting the estimation on Dynare
%-----------------------------------

% dynare NK_SOE_model_v7.mod

%-----------------------------------
% Computing the theoretical moments
%-----------------------------------

load('NK_SOE_model_v9_results.mat');

vlist   = {'y','y_t','y_n','c','pi','r','q','e','s'};
for j = 1 : length(vlist)
model_acf(:,j)   = autocorr(eval(strcat('oo_.SmoothedVariables.Mean.',vlist{j})),4);
model_adf(1,j)   = adftest(eval(strcat('oo_.SmoothedVariables.Mean.',vlist{j})),'model','ARD');  % ADF test for stationarity
model_std(1,j)   = std(eval(strcat('oo_.SmoothedVariables.Mean.',vlist{j})));
model_relstd(1,j)= std(eval(strcat('oo_.SmoothedVariables.Mean.',vlist{j})))/std(eval(strcat('oo_.SmoothedVariables.Mean.',vlist{1})));
model_corr(1,j)  = corr(eval(strcat('oo_.SmoothedVariables.Mean.',vlist{1})),eval(strcat('oo_.SmoothedVariables.Mean.',vlist{j})));
end


%-----------------------------------
% Plotting historical simulation
%-----------------------------------

load('NK_SOE_model_v9_results.mat');


vlist   = {'y','y_t','y_n','c','pi','r','q','s'};
vnames  = {'Total Output','Tradables Output','Non-tradables Output','Consumption','CPI inflation','Nominal interest rate','Real exchange rate','Terms of trade'};



% % Using updated variables
% figure('Name','Using updated variables')
% for j = 1 : length(vnames)
%     subplot(3,3,j)
%     AX = plot(dates,eval(strcat(vlist{j},'_hat')),'b',dates,eval(strcat('[0; oo_.UpdatedVariables.Mean.',vlist{j},']')),'-r');
%     set(gca,'xlim',[startdate enddate],'xtick',[startdate:2:enddate]);
%     title(vnames{j});
%     hold all
% end
% hold off
% 
% % Using filtered variables (one step ahead forecast)
% figure('Name','Using filtered variables')
% for j = 1 : length(vnames)
%     subplot(3,3,j)
%     AX = plot(dates,eval(strcat(vlist{j},'_hat')),'b',dates,eval(strcat('[0; oo_.FilteredVariables.Mean.',vlist{j},']')),'-r');
%     set(gca,'xlim',[startdate enddate],'xtick',[startdate:2:enddate]);
%     title(vnames{j});
%     hold all
% end
% hold off

% Using smoothed variables (using all information)
figure('Name','Using smoothed variables (1)')
for j = 1 : 4
    subplot(2,2,j)
    AX = plot(dates,eval(strcat(vlist{j},'_hat')),'b',dates,eval(strcat('[0; oo_.SmoothedVariables.Mean.',vlist{j},']')),'--r');
    set(gca,'xlim',[startdate enddate],'xtick',[startdate:2:enddate]);
    title(vnames{j},'fontsize',16);
    hold all
end
hold off

figure('Name','Using smoothed variables (2)')
for j = 5 : 8
    subplot(2,2,j-4)
    AX = plot(dates,eval(strcat(vlist{j},'_hat')),'b',dates,eval(strcat('[0; oo_.SmoothedVariables.Mean.',vlist{j},']')),'--r');
    set(gca,'xlim',[startdate enddate],'xtick',[startdate:2:enddate]);
    title(vnames{j},'fontsize',16);
    hold all
end
hold off

%-----------------------------------
% Plotting Bayesian IRFs
%-----------------------------------

% dynare NK_SOE_model_v9_sim.mod noclearall                         % Launch simulation using new posterior parameters
load('NK_SOE_model_v9_sim_results.mat');                % Load simulation results

sim_irf = oo_.irfs;

load('NK_SOE_model_v9_results.mat');                    % Loading Bayesian estimation results

post_param = oo_.posterior_mean.parameters;             % Loading posterior parameters
save('post_param.mat', '-struct','post_param');                   % Save posterior parameters for simulation

post_shock = oo_.posterior_mean.shocks_std;             % Loading posterior shock std

[post_shock.sigma_at] = post_shock.eps_at;              % Renaming shocks to load in Dynare
post_shock = rmfield(post_shock,'eps_at');
[post_shock.sigma_an] = post_shock.eps_an;
post_shock = rmfield(post_shock,'eps_an');
[post_shock.sigma_r] = post_shock.eps_r;
post_shock = rmfield(post_shock,'eps_r');
save('post_shock.mat', '-struct','post_shock');                   % Save posterior shock std for simulation

post_irf = oo_.PosteriorIRF.dsge;


hor = 40;
xx = zeros(hor,1);


slist   = {'eps_at','eps_an','eps_r','eps_cstar','eps_pistar'};
snames  = {'Tradables productivity shock','Non-tradables productivity shock','Interest rate shock','World consumption shock','Imported inflation shock'};

vlist   = {'y','y_t','y_nf','y_ni','rw_f','rw_i','c','c_th','c_tf','pi','pi_t','pi_nf','pi_ni','r','q','s'};
vnames  = {'Total Output','Tradables Output','Formal Non-tradables Output/Consumption','Informal Non-tradables Output/Consumption','Real formal wage','Real informal wage','Consumption','Domestic tradables consumption','Imports consumption','CPI inflation','Tradables inflation','Formal non-tradables inflation','Informal non-tradables inflation','Nominal interest rate','Real exchange rate','Terms of trade'};


for j = 1 : length(slist)

post_irf.Mean.(strcat('rw_f_',slist{j})) = eval(strcat('(post_irf.Mean.w_f_',slist{j},')')) - eval(strcat('(post_irf.Mean.p_',slist{j},')'));

post_irf.Mean.(strcat('rw_i_',slist{j})) = eval(strcat('(post_irf.Mean.w_i_',slist{j},')')) - eval(strcat('(post_irf.Mean.p_',slist{j},')'));

post_irf.HPDinf.(strcat('rw_f_',slist{j})) = eval(strcat('(post_irf.HPDinf.w_f_',slist{j},')')) - eval(strcat('(post_irf.HPDinf.p_',slist{j},')'));

post_irf.HPDsup.(strcat('rw_f_',slist{j})) = eval(strcat('(post_irf.HPDsup.w_f_',slist{j},')')) - eval(strcat('(post_irf.HPDsup.p_',slist{j},')'));

post_irf.HPDinf.(strcat('rw_i_',slist{j})) = eval(strcat('(post_irf.HPDinf.w_i_',slist{j},')')) - eval(strcat('(post_irf.HPDinf.p_',slist{j},')'));

post_irf.HPDsup.(strcat('rw_i_',slist{j})) = eval(strcat('(post_irf.HPDsup.w_i_',slist{j},')')) - eval(strcat('(post_irf.HPDsup.p_',slist{j},')'));

sim_irf.(strcat('rw_f_',slist{j})) = eval(strcat('(sim_irf.w_f_',slist{j},')')) - eval(strcat('(sim_irf.p_',slist{j},')'));

sim_irf.(strcat('rw_i_',slist{j})) = eval(strcat('(sim_irf.w_i_',slist{j},')')) - eval(strcat('(sim_irf.p_',slist{j},')'));

end



    for j = 1 : length(snames)

         
        
    for jj = 1 : 4
        
     
    figure('name',strcat(snames{j},'-',num2str(jj)))
         
            
    for jjj = (1+(length(vnames)/4*(jj-1))) : ((length(vnames)/4)+(length(vnames)/4*(jj-1)))

        scalea = min(eval(strcat('post_irf.HPDinf.',vlist{jjj},'_',slist{j}))).*100;

        subplot(2,2,jjj-(length(vnames)/4*(jj-1)))
            area(0:1:hor-1,eval(strcat('post_irf.HPDsup.',vlist{jjj},'_',slist{j})).*100,scalea,'FaceColor',[.7 .7 .7],...
                'EdgeColor','k','LineWidth',.5,'Linestyle','none');
        hold on
            area(0:1:hor-1,eval(strcat('post_irf.HPDinf.',vlist{jjj},'_',slist{j})).*100,scalea,'FaceColor',[1 1 1],...
                'EdgeColor','k','LineWidth',.5,'Linestyle','none');
        hold on

        % -----------------------------------------------
        % The main figure
        % -----------------------------------------------
        jm = plot(0:1:hor-1,eval(strcat('post_irf.Mean.',vlist{jjj},'_',slist{j})).*100,'r');
        %set(jm(1),'linewidth',1,'Color','r')
       
        jmm = plot(0:1:hor-1,eval(strcat('sim_irf.',vlist{jjj},'_',slist{j})).*100,'b');
        %set(jm(1),'linewidth',1)

        jxx = plot(0:1:hor-1,xx','k');
        set(jxx(1),'linewidth',0.5)
                
        title(vnames{jjj},'fontsize',12)
        xlabel('Quarters after shock','fontsize',10)
        ylabel('Percent deviation','fontsize',10)
        
        %legend show;

        axis tight
        set(gca,'Layer','top')
        
        
        
    end
    
    print('-dpng',strcat(snames{j},'-',num2str(jj)))
    
    end

    end

    % For legend see http://stackoverflow.com/questions/13685967/how-to-show-legend-for-only-a-specific-subset-of-curves-in-the-plotting
    
    
