load data_est;

endvars = {'y_t' 'y_nf' 'pi' 'r' 'q'}; 
%endvars = sort(endvars);

for i=1:length(endvars)
    eval(strcat(endvars{i}, '=','data_est(:,',num2str(i),')',';'));
end